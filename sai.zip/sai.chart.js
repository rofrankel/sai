(function(){
  var __hasProp = Object.prototype.hasOwnProperty, __extends = function(child, parent) {
    var ctor = function(){ };
    ctor.prototype = parent.prototype;
    child.__superClass__ = parent.prototype;
    child.prototype = new ctor();
    child.prototype.constructor = child;
  };
  Sai.Chart = function(r, x, y, w, h, data, bgcolor, title_text, interactive) {
    var _a;
    _a = this;
    this.drawInfo = function(){ return Sai.Chart.prototype.drawInfo.apply(_a, arguments); };
    this.r = r;
    this.x = x || 0;
    this.y = y || 0;
    this.w = w || 640;
    this.h = h || 480;
    this.setData(data);
    this.title_text = title_text;
    this.interactive = interactive;
    this.bgcolor = (typeof bgcolor !== "undefined" && bgcolor !== null) ? bgcolor : 'white';
    this.padding = {
      left: 2,
      right: 2,
      top: 2,
      bottom: 2
    };
    return this;
  };
  Sai.Chart.prototype.groupsToNullPad = function() {
    return [];
  };
  Sai.Chart.prototype.setData = function(data) {
    var _a, _b, _c, _d, _e, _f, _g, group, groups, series;
    this.data = {};
    _a = data;
    for (series in _a) { if (__hasProp.call(_a, series)) {
      this.data[series] = data[series].slice(0);
    }}
    groups = this.dataGroups(data);
    _c = this.groupsToNullPad();
    for (_b = 0, _d = _c.length; _b < _d; _b++) {
      group = _c[_b];
      _f = groups[group];
      for (_e = 0, _g = _f.length; _e < _g; _e++) {
        series = _f[_e];
        this.nullPad(series);
      }
    }
    this.ndata = this.normalize(this.data);
    return this.ndata;
  };
  Sai.Chart.prototype.nullPad = function(seriesName) {
    if (seriesName in this.data) {
      this.data[seriesName] = [null].concat(this.data[seriesName].concat([null]));
      return this.data[seriesName];
    }
  };
  Sai.Chart.prototype.caresAbout = function(seriesName) {
    return !seriesName.match("^__");
  };
  Sai.Chart.prototype.dataGroups = function(data) {
    var _a, _b, _c, _d, seriesName;
    return {
      'all': (function() {
        _a = []; _b = data;
        for (seriesName in _b) { if (__hasProp.call(_b, seriesName)) {
          this.caresAbout(seriesName) ? _a.push(seriesName) : null;
        }}
        return _a;
      }).call(this),
      '__META__': (function() {
        _c = []; _d = data;
        for (seriesName in _d) { if (__hasProp.call(_d, seriesName)) {
          seriesName.match("^__") ? _c.push(seriesName) : null;
        }}
        return _c;
      })()
    };
  };
  Sai.Chart.prototype.getYAxisVals = function(min, max) {
    var _a, bottom, i, mag, rawmag, step, top;
    mag = Math.floor((rawmag = (Math.log(max - min) / Math.LN10) - 0.4));
    step = Math.pow(10, mag);
    if (rawmag % 1 > 0.7) {
      step *= 4;
    } else if (rawmag % 1 > 0.35) {
      step *= 2;
    }
    bottom = Sai.util.round(min - (step / 1.9), step);
    if ((bottom < 0) && (0 <= min)) {
      bottom = 0;
    }
    top = Sai.util.round(max + (step / 1.9), step);
    _a = [];
    for (i = bottom; i <= top; i += step) {
      _a.push(Sai.util.round(i, step));
    }
    return _a;
  };
  Sai.Chart.prototype.getMax = function(data, group) {
    var _a, _b, _c, _d, _e, _f, _g, _h, d, series;
    return Math.max.apply(Math, (function() {
      _a = []; _c = group;
      for (_b = 0, _d = _c.length; _b < _d; _b++) {
        series = _c[_b];
        _a.push(Math.max.apply(Math, (function() {
          _e = []; _g = data[series];
          for (_f = 0, _h = _g.length; _f < _h; _f++) {
            d = _g[_f];
            d !== null ? _e.push(d) : null;
          }
          return _e;
        })()));
      }
      return _a;
    })());
  };
  Sai.Chart.prototype.getMin = function(data, group) {
    var _a, _b, _c, _d, _e, _f, _g, _h, d, series;
    return Math.min.apply(Math, (function() {
      _a = []; _c = group;
      for (_b = 0, _d = _c.length; _b < _d; _b++) {
        series = _c[_b];
        _a.push(Math.min.apply(Math, (function() {
          _e = []; _g = data[series];
          for (_f = 0, _h = _g.length; _f < _h; _f++) {
            d = _g[_f];
            d !== null ? _e.push(d) : null;
          }
          return _e;
        })()));
      }
      return _a;
    })());
  };
  Sai.Chart.prototype.normalize = function(data) {
    var _a, _b, _c, _d, _e, _f, _g, _h, group, groups, i, max, min, ndata, series, yvals;
    groups = this.dataGroups(data);
    ndata = {};
    _a = groups;
    for (group in _a) { if (__hasProp.call(_a, group)) {
      if (group === '__META__') {
        continue;
      }
      ndata[group] = {};
      max = this.getMax(data, groups[group]);
      min = this.getMin(data, groups[group]);
      yvals = this.getYAxisVals(min, max);
      min = yvals[0];
      max = yvals[yvals.length - 1];
      _c = groups[group];
      for (_b = 0, _d = _c.length; _b < _d; _b++) {
        series = _c[_b];
        if (!((typeof (_e = data[series]) !== "undefined" && _e !== null))) {
          continue;
        }
        ndata[group][series] = (function() {
          _f = []; (_g = data[series].length);

          for (i = 0; i < _g; i += 1) {
            _f.push(((typeof (_h = data[series][i]) !== "undefined" && _h !== null) && [i / (data[series].length - 1), ((data[series][i] - min) / (max - min))] || null));
          }
          return _f;
        })();
        ndata[group].__YVALS__ = yvals;
      }
    }}
    return ndata;
  };
  Sai.Chart.prototype.addAxes = function(group) {
    var LINE_HEIGHT, _a, haxis_height, hlen, vlen;
    LINE_HEIGHT = 10;
    this.axisWidth = 1.5;
    haxis_height = LINE_HEIGHT + 2 + 10;
    this.padding.top += 5;
    (typeof (_a = this.data['__LABELS__'][this.data['__LABELS__'].length - 1]) !== "undefined" && _a !== null) ? this.padding.right += (this.data['__LABELS__'][this.data['__LABELS__'].length - 1].length / 2) * 5 : null;
    vlen = this.h - (this.padding.bottom + haxis_height + this.padding.top);
    this.vaxis = this.r.sai.prim.vaxis(this.ndata[group].__YVALS__, this.x + this.padding.left, this.y - (this.padding.bottom + haxis_height), vlen, this.axisWidth);
    this.vaxis.translate(this.vaxis.getBBox().width, 0);
    this.padding.left += this.vaxis.getBBox().width;
    hlen = this.w - this.padding.left - this.padding.right;
    this.haxis = this.r.sai.prim.haxis(this.data['__LABELS__'], this.x + this.padding.left, this.y - this.padding.bottom, hlen, this.axisWidth);
    this.haxis.translate(0, -haxis_height);
    this.padding.bottom += haxis_height;
    this.px = this.x + this.padding.left;
    this.py = this.y - this.padding.bottom;
    this.pw = this.w - this.padding.left - this.padding.right;
    this.ph = this.h - this.padding.bottom - this.padding.top;
    return this.r.set().push(this.haxis).push(this.vaxis);
  };
  Sai.Chart.prototype.drawBG = function() {
    var _a, _b, _c, _d;
    this.bg = this.r.rect((typeof (_a = this.px) !== "undefined" && _a !== null) && this.px || this.x, (typeof (_b = this.py) !== "undefined" && _b !== null) && (this.py - this.ph) || (this.y - this.h), (typeof (_c = this.pw) !== "undefined" && _c !== null) && this.pw || this.w, (typeof (_d = this.ph) !== "undefined" && _d !== null) && this.ph || this.h).attr({
      fill: this.bgcolor,
      'stroke-width': 0,
      'stroke-opacity': 0
    }).toBack();
    return this.bg;
  };
  Sai.Chart.prototype.logoPos = function() {
    var h, w;
    w = 160;
    h = 34;
    return [this.px + this.pw - w - 5, this.py - this.ph + 5, w, h];
  };
  Sai.Chart.prototype.drawLogo = function() {
    var _a, h, w, x, y;
    _a = this.logoPos();
    x = _a[0];
    y = _a[1];
    w = _a[2];
    h = _a[3];
    this.logo = this.r.image(Sai.imagePath + 'logo.png', x, y, w, h).attr({
      opacity: 0.25
    });
    return this.logo;
  };
  Sai.Chart.prototype.render = function() {
    var _a;
    this.plot = (typeof (_a = this.plot) !== "undefined" && _a !== null) ? this.plot : new Sai.Plot(this.r);
    this.plot.render();
    return this;
  };
  Sai.Chart.prototype.setColors = function(colors) {
    var _a, _b, series;
    this.colors = (typeof (_a = this.colors) !== "undefined" && _a !== null) ? this.colors : {};
    _b = colors;
    for (series in _b) { if (__hasProp.call(_b, series)) {
      series in this.data ? (this.colors[series] = colors[series]) : null;
    }}
    return this;
  };
  Sai.Chart.prototype.setColor = function(series, color) {
    var _a;
    this.colors = (typeof (_a = this.colors) !== "undefined" && _a !== null) ? this.colors : {};
    this.colors[series] = color;
    return this;
  };
  Sai.Chart.prototype.drawGuideline = function(h, group) {
    var nh, ymax, ymin;
    group = (typeof group !== "undefined" && group !== null) ? group : 'all';
    ymin = this.ndata[group].__YVALS__[0];
    ymax = this.ndata[group].__YVALS__[this.ndata[group].__YVALS__.length - 1];
    if (!(h > ymin)) {
      return null;
    }
    nh = (h - ymin) / (ymax - ymin);
    this.guideline = (new Sai.LinePlot(this.r, this.px, this.py, this.pw, this.ph, [[0, nh], [1, nh]])).render('#ccc');
    return this.guideline;
  };
  Sai.Chart.prototype.drawLegend = function(colors) {
    colors = (typeof colors !== "undefined" && colors !== null) ? colors : this.colors;
    if (colors) {
      this.legend = this.r.sai.prim.legend(this.x, this.y - this.padding.bottom, this.w, colors);
      this.padding.bottom += this.legend.getBBox().height + 15;
      return this.legend.translate((this.w - this.legend.getBBox().width) / 2, 0);
    }
  };
  Sai.Chart.prototype.drawTitle = function() {
    var _a;
    if ((typeof (_a = this.title_text) !== "undefined" && _a !== null)) {
      this.title = this.r.text(this.x + (this.w / 2), this.y - this.h, this.title_text).attr({
        'font-size': 20
      });
      this.title.translate(0, this.title.getBBox().height / 2);
      return this.padding.top += this.title.getBBox().height + 5;
    }
  };
  Sai.Chart.prototype.setupInfoSpace = function() {
    this.info_y = this.y - this.h + this.padding.top;
    this.info_x = this.x + this.padding.left;
    this.info_w = this.w - this.padding.left - this.padding.right;
    return this.padding.top += 30;
  };
  Sai.Chart.prototype.drawInfo = function(info, clear) {
    var _a, label;
    clear = (typeof clear !== "undefined" && clear !== null) ? clear : true;
    clear ? (this.info_data = {}) : null;
    this.info ? this.info.remove() : null;
    _a = info;
    for (label in _a) { if (__hasProp.call(_a, label)) {
      this.info_data[label] = info[label];
    }}
    this.info = this.r.sai.prim.info(this.info_x, this.info_y, this.info_w, this.info_data);
    return this.info;
  };
  Sai.Chart.prototype.getIndex = function(mx, my) {
    var tx;
    tx = Sai.util.transformCoords({
      x: mx,
      y: my
    }, this.r.canvas).x;
    return Math.round((this.data.__LABELS__.length - 1) * (tx - this.px) / this.pw);
  };

  Sai.LineChart = function() {
    return Sai.Chart.apply(this, arguments);
  };
  __extends(Sai.LineChart, Sai.Chart);
  Sai.LineChart.prototype.render = function() {
    var _a, color, line, series;
    this.drawTitle();
    this.setupInfoSpace();
    this.drawLegend();
    this.addAxes('all');
    this.drawBG();
    this.drawLogo();
    this.drawGuideline(0);
    this.lines = [];
    this.dots = this.r.set();
    this.plots = this.r.set();
    _a = this.ndata['all'];
    for (series in _a) { if (__hasProp.call(_a, series)) {
      if (series === '__YVALS__') {
        continue;
      }
      color = this.colors && this.colors[series] || 'black';
      line = (new Sai.LinePlot(this.r, this.px, this.py, this.pw, this.ph, this.ndata['all'][series])).render(color, 3);
      this.lines.push(line);
      this.plots.push(line.set);
      this.dots.push(this.r.circle(0, 0, 4).attr({
        'fill': color
      }).hide());
    }}
    this.r.set().push(this.bg, this.plots, this.dots, this.logo).mousemove((function(__this) {
      var __func = function(event) {
        var _b, _c, _d, _e, i, idx, info, pos;
        idx = this.getIndex(event.clientX, event.clientY);
        info = {};
        _b = this.ndata['all'];
        for (series in _b) { if (__hasProp.call(_b, series)) {
          (typeof (_c = this.data[series]) !== "undefined" && _c !== null) ? (info[series] = this.data[series][idx]) : null;
        }}
        this.drawInfo(info);
        _d = []; (_e = this.lines.length);

        for (i = 0; i < _e; i += 1) {
          _d.push((function() {
            pos = this.lines[i].dndata[idx];
            return this.dots[i].attr({
              cx: pos[0],
              cy: pos[1]
            }).show().toFront();
          }).call(this));
        }
        return _d;
      };
      return (function() {
        return __func.apply(__this, arguments);
      });
    })(this)).mouseout((function(__this) {
      var __func = function(event) {
        this.drawInfo({});
        return this.dots.hide();
      };
      return (function() {
        return __func.apply(__this, arguments);
      });
    })(this));
    return this;
  };

  Sai.Sparkline = function() {
    return Sai.Chart.apply(this, arguments);
  };
  __extends(Sai.Sparkline, Sai.Chart);
  Sai.Sparkline.prototype.dataGroups = function(data) {
    return {
      'data': ['data']
    };
  };
  Sai.Sparkline.prototype.render = function() {
    this.drawBG();
    this.plots = this.r.set();
    this.plots.push((new Sai.LinePlot(this.r, this.x, this.y, this.w, this.h, this.ndata['data']['data'])).render(this.colors && this.colors[series] || 'black', 1).set);
    return this;
  };

  Sai.BarChart = function() {
    return Sai.Chart.apply(this, arguments);
  };
  __extends(Sai.BarChart, Sai.Chart);
  Sai.BarChart.prototype.groupsToNullPad = function() {
    var _a, _b, group;
    _a = []; _b = this.dataGroups();
    for (group in _b) { if (__hasProp.call(_b, group)) {
      _a.push(group);
    }}
    return _a;
  };
  Sai.BarChart.prototype.render = function() {
    var _a, _b, _c, _d, _e, data, rawdata, series, yval;
    this.drawTitle();
    this.setupInfoSpace();
    this.drawLegend();
    this.addAxes('all', {
      left: 30,
      right: 0,
      top: 0,
      bottom: 20
    });
    this.drawLogo();
    this.drawBG();
    this.guidelines = this.r.set();
    _b = this.ndata['all']['__YVALS__'];
    for (_a = 0, _c = _b.length; _a < _c; _a++) {
      yval = _b[_a];
      this.drawGuideline(yval);
    }
    this.plots = this.r.set();
    data = {};
    rawdata = {};
    _d = this.ndata['all'];
    for (series in _d) { if (__hasProp.call(_d, series)) {
      if (!(series.match('^__'))) {
        data[series] = this.ndata['all'][series];
        rawdata[series] = this.data[series];
      }
    }}
    this.plots.push((new Sai.BarPlot(this.r, this.px, this.py, this.pw, this.ph, data, rawdata)).render((typeof (_e = this.stacked) !== "undefined" && _e !== null), this.colors, this.interactive, this.drawInfo).set);
    return this;
  };

  Sai.StackedBarChart = function() {
    return Sai.BarChart.apply(this, arguments);
  };
  __extends(Sai.StackedBarChart, Sai.BarChart);
  Sai.StackedBarChart.prototype.stacked = true;
  Sai.StackedBarChart.prototype.getMax = function(data, group) {
    var _a, _b, _c, _d, _e, _f, i, series;
    return Math.max.apply(Math, (function() {
      _a = []; (_b = this.data['__LABELS__'].length);

      for (i = 0; i < _b; i += 1) {
        _a.push(Sai.util.sumArray((function() {
          _c = []; _e = group;
          for (_d = 0, _f = _e.length; _d < _f; _d++) {
            series = _e[_d];
            _c.push(data[series][i]);
          }
          return _c;
        })()));
      }
      return _a;
    }).call(this));
  };
  Sai.StackedBarChart.prototype.getMin = function(data, group) {
    return 0;
  };

  Sai.StockChart = function() {
    return Sai.Chart.apply(this, arguments);
  };
  __extends(Sai.StockChart, Sai.Chart);
  Sai.StockChart.prototype.groupsToNullPad = function() {
    var _a, _b, group;
    _a = []; _b = this.dataGroups();
    for (group in _b) { if (__hasProp.call(_b, group)) {
      _a.push(group);
    }}
    return _a;
  };
  Sai.StockChart.prototype.dataGroups = function(data) {
    var _a, _b, seriesName;
    return {
      '__META__': ['__LABELS__'],
      'volume': ['volume'],
      'prices': (function() {
        _a = []; _b = data;
        for (seriesName in _b) { if (__hasProp.call(_b, seriesName)) {
          this.caresAbout(seriesName) && !('__LABELS__' === seriesName || 'volume' === seriesName) ? _a.push(seriesName) : null;
        }}
        return _a;
      }).call(this)
    };
  };
  Sai.StockChart.prototype.render = function() {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, glow_width, i, p, rawdata, series, vol;
    this.drawTitle();
    this.setupInfoSpace();
    this.colors = (typeof (_a = this.colors) !== "undefined" && _a !== null) ? this.colors : {};
    this.colors['up'] = (typeof (_b = this.colors['up']) !== "undefined" && _b !== null) ? this.colors['up'] : 'black';
    this.colors['down'] = (typeof (_c = this.colors['down']) !== "undefined" && _c !== null) ? this.colors['down'] : 'red';
    this.colors['vol_up'] = (typeof (_d = this.colors['vol_up']) !== "undefined" && _d !== null) ? this.colors['vol_up'] : '#666';
    this.colors['vol_down'] = (typeof (_e = this.colors['vol_down']) !== "undefined" && _e !== null) ? this.colors['vol_down'] : '#c66';
    this.addAxes('prices', {
      left: 30,
      right: 0,
      top: 0,
      bottom: 20
    });
    this.drawLogo();
    this.drawBG();
    this.drawGuideline(0, 'prices');
    this.plots = this.r.set();
    vol = {
      'up': [],
      'down': []
    };
    rawdata = {};
    _f = this.ndata['prices'];
    for (p in _f) { if (__hasProp.call(_f, p)) {
      !(p.match('^__')) ? (rawdata[p] = this.data[p]) : null;
    }}
    (typeof (_g = this.data['volume']) !== "undefined" && _g !== null) ? (rawdata['vol'] = this.data['volume']) : null;
    if ('volume' in this.ndata.volume) {
      (_h = this.ndata['volume']['volume'].length);

      for (i = 0; i < _h; i += 1) {
        if (this.ndata['volume']['volume'][i] !== null) {
          if (i && this.ndata['prices']['close'][i - 1] && (this.ndata['prices']['close'][i][1] < this.ndata['prices']['close'][i - 1][1])) {
            vol.down.push(this.ndata['volume']['volume'][i]);
            vol.up.push([this.ndata['volume']['volume'][i][0], 0]);
          } else {
            vol.up.push(this.ndata['volume']['volume'][i]);
            vol.down.push([this.ndata['volume']['volume'][i][0], 0]);
          }
        } else {
          vol.up.push([0, 0]);
          vol.down.push([0, 0]);
        }
      }
      this.plots.push((new Sai.BarPlot(this.r, this.px, this.py, this.pw, this.ph * 0.2, vol, rawdata)).render(true, {
        'up': this.colors['vol_up'],
        'down': this.colors['vol_down']
      }, this.interactive, this.drawInfo).set);
    }
    this.plots.push((new Sai.CandlestickPlot(this.r, this.px, this.py, this.pw, this.ph, {
      'open': this.ndata['prices']['open'],
      'close': this.ndata['prices']['close'],
      'high': this.ndata['prices']['high'],
      'low': this.ndata['prices']['low']
    }, rawdata)).render(this.colors, Math.min(5, (this.pw / this.ndata['prices']['open'].length) - 2), false, this.drawInfo).set);
    _i = this.ndata['prices'];
    for (series in _i) { if (__hasProp.call(_i, series)) {
      if (('open' === series || 'close' === series || 'high' === series || 'low' === series) || series.match("^__")) {
        continue;
      }
      this.plots.push((new Sai.LinePlot(this.r, this.px, this.py, this.pw, this.ph, this.ndata['prices'][series])).render(this.colors && this.colors[series] || 'black').set);
    }}
    glow_width = this.pw / (this.data.__LABELS__.length - 1);
    this.glow = this.r.rect(this.px - (glow_width / 2), this.py - this.ph, glow_width, this.ph).attr({
      fill: ("0-" + this.bgcolor + "-#DDAA99-" + this.bgcolor),
      'stroke-width': 0,
      'stroke-opacity': 0
    }).toBack().hide();
    this.bg.toBack();
    this.r.set().push(this.bg, this.plots, this.logo, this.glow).mousemove((function(__this) {
      var __func = function(event) {
        var _j, _k, idx, info, notNull;
        idx = this.getIndex(event.clientX, event.clientY);
        info = {};
        notNull = true;
        _j = this.ndata['prices'];
        for (series in _j) { if (__hasProp.call(_j, series)) {
          (typeof (_k = this.data[series]) !== "undefined" && _k !== null) ? (info[series] = this.data[series][idx]) : null;
          info[series] === null ? (notNull = false) : null;
        }}
        this.drawInfo(info);
        if (notNull) {
          return this.glow.attr({
            x: this.px + (glow_width * (idx - 0.5))
          }).show();
        }
      };
      return (function() {
        return __func.apply(__this, arguments);
      });
    })(this)).mouseout((function(__this) {
      var __func = function(event) {
        this.drawInfo({});
        return this.glow.hide();
      };
      return (function() {
        return __func.apply(__this, arguments);
      });
    })(this));
    return this;
  };

})();
