(function(){
  var _a, getHoverfuncs;
  var __hasProp = Object.prototype.hasOwnProperty;
  Raphael.fn.sai.prim = (typeof (_a = Raphael.fn.sai.prim) !== "undefined" && _a !== null) ? Raphael.fn.sai.prim : {};
  getHoverfuncs = function(target, attrOn, attrOff, extras) {
    return [
      function() {
        target.attr(attrOn);
        if (extras) {
          return extras[0]();
        }
      }, function() {
        target.attr(attrOff);
        if (extras) {
          return extras[1]();
        }
      }
    ];
  };
  Raphael.fn.sai.prim.candlestick = function(x, by0, by1, sy0, sy1, body_width, color, fill, shouldInteract, fSetInfo, extras) {
    var body, bx, candlestick, hoverfuncs, shadow;
    color = (typeof color !== "undefined" && color !== null) ? color : '#000';
    if (!(body_width % 2)) {
      body_width++;
    }
    bx = x - (body_width / 2.0);
    body = this.rect(bx, by0, body_width, by1 - by0 || 1).attr('stroke', color);
    shadow = this.path("M" + x + " " + sy0 + "L" + x + " " + by0 + "M" + x + " " + by1 + "L" + x + " " + sy1).attr('stroke', color);
    body.attr('fill', fill ? color : 'white');
    candlestick = this.set().push(body, shadow);
    if (shouldInteract) {
      hoverfuncs = getHoverfuncs(candlestick, {
        scale: '1.5,1.5,' + x + ',' + (by0 + (by1 - by0) / 2),
        'fill-opacity': 0.5
      }, {
        scale: '1.0,1.0,' + x + ',' + (by0 + (by1 - by0) / 2),
        'fill-opacity': 1.0
      }, extras);
      candlestick.hover(hoverfuncs[0], hoverfuncs[1]);
    }
    return candlestick;
  };
  Raphael.fn.sai.prim.line = function(coords, color, width) {
    var _b, _c, _d, coord, path;
    color = (typeof color !== "undefined" && color !== null) ? color : '#000';
    width = (typeof width !== "undefined" && width !== null) ? width : 1;
    _c = coords;
    for (_b = 0, _d = _c.length; _b < _d; _b++) {
      coord = _c[_b];
      if (!(typeof coord !== "undefined" && coord !== null)) {
        continue;
      }
      (typeof path !== "undefined" && path !== null) ? path += ("L" + coord[0] + " " + coord[1]) : (path = ("M" + coord[0] + " " + coord[1]));
    }
    return this.path(path).attr({
      'stroke': color,
      'stroke-width': width
    });
  };
  Raphael.fn.sai.prim.stackedBar = function(coords, colors, width, baseline, shouldInteract, fSetInfo, extras) {
    var _b, _baseline, _c, _d, _e, bar, height, hoverfuncs, i, stack, totalHeight;
    if (shouldInteract && (typeof (_c = coords[coords.length - 1]) !== "undefined" && _c !== null)) {
      totalHeight = 0;
      (_b = coords.length);

      for (i = 0; i < _b; i += 1) {
        totalHeight += baseline - coords[i][1];
      }
    }
    width *= .67;
    stack = this.set();
    _baseline = baseline;
    (_d = coords.length);

    for (i = 0; i < _d; i += 1) {
      if (!((typeof (_e = coords[i]) !== "undefined" && _e !== null) && coords[i][1] !== baseline)) {
        continue;
      }
      _baseline = coords[i][1] - (baseline - _baseline);
      height = baseline - coords[i][1];
      stack.push((bar = this.rect(coords[i][0] - (width / 2.0), _baseline - (i === 0 ? 1 : 0), width, height).attr('fill', colors && colors[i] || 'black').attr('stroke', colors && colors[i] || 'black')));
      if (shouldInteract) {
        hoverfuncs = getHoverfuncs(bar, {
          'fill-opacity': '0.75'
        }, {
          'fill-opacity': '1.0'
        }, [
          (function(_percent) {
            return function() {
              extras[0] ? extras[0]() : null;
              return fSetInfo({
                '(selected)': Sai.util.prettystr(_percent) + '%'
              }, false);
            };
          })(100 * height / totalHeight), extras[1]
        ], extras);
        bar.hover(hoverfuncs[0], hoverfuncs[1]);
      }
    }
    return stack;
  };
  Raphael.fn.sai.prim.groupedBar = function(coords, colors, width, baseline, shouldInteract, fSetInfo, extras) {
    var _b, _c, _d, barwidth, group, hoverfuncs, i, x;
    group = this.set();
    if (!((typeof (_b = coords[0]) !== "undefined" && _b !== null))) {
      return group;
    }
    barwidth = width / (coords.length + 1);
    x = coords[0][0] - ((width - barwidth) / 2);
    (_c = coords.length);

    for (i = 0; i < _c; i += 1) {
      if (!((typeof (_d = coords[i]) !== "undefined" && _d !== null))) {
        continue;
      }
      group.push(this.rect(x, coords[i][1] - (i === 0 ? 1 : 0), barwidth, baseline - coords[i][1]).attr('fill', colors && colors[i] || 'black').attr('stroke', colors && colors[i] || 'black'));
      x += barwidth;
    }
    if (shouldInteract) {
      hoverfuncs = getHoverfuncs(group, {
        'fill-opacity': '0.75'
      }, {
        'fill-opacity': '1.0'
      }, extras);
      group.hover(hoverfuncs[0], hoverfuncs[1]);
    }
    return group;
  };
  Raphael.fn.sai.prim.haxis = function(vals, x, y, len, width, color, ticklens) {
    var _b, _c, _d, dx, label, labels, line, ticklen, ticks, val, xpos;
    ticklens = (typeof ticklens !== "undefined" && ticklens !== null) ? ticklens : [10, 5];
    width = (typeof width !== "undefined" && width !== null) ? width : 1;
    color = (typeof color !== "undefined" && color !== null) ? color : '#000';
    line = this.path("M" + x + " " + y + "l" + len + " 0").attr('stroke', color);
    ticks = this.set();
    labels = this.set();
    dx = len / (vals.length - 1);
    xpos = x;
    _c = vals;
    for (_b = 0, _d = _c.length; _b < _d; _b++) {
      val = _c[_b];
      if (!(val === null)) {
        ticklen = ticklens[String(val) ? 0 : 1];
        ticks.push(this.path("M" + xpos + " " + y + "l0 " + ticklen).attr('stroke', color));
        if (!(val === '')) {
          label = this.text(xpos, y + ticklen + 2, Sai.util.prettystr(val));
          label.attr('y', label.attr('y') + (label.getBBox().height / 2.0));
          labels.push(label);
        }
      }
      xpos += dx;
    }
    return this.set().push(line, ticks, labels);
  };
  Raphael.fn.sai.prim.vaxis = function(vals, x, y, len, width, color, ticklens) {
    var _b, _c, _d, dy, label, labels, line, ticklen, ticks, val, ypos;
    ticklens = (typeof ticklens !== "undefined" && ticklens !== null) ? ticklens : [10, 5];
    width = (typeof width !== "undefined" && width !== null) ? width : 1;
    color = (typeof color !== "undefined" && color !== null) ? color : '#000';
    line = this.path("M" + x + " " + y + "l0 " + (-len)).attr('stroke', color);
    ticks = this.set();
    labels = this.set();
    dy = len / (vals.length - 1);
    ypos = y;
    _c = vals;
    for (_b = 0, _d = _c.length; _b < _d; _b++) {
      val = _c[_b];
      if (!(val === null)) {
        ticklen = ticklens[String(val) ? 0 : 1];
        ticks.push(this.path("M" + x + " " + ypos + "l" + (-ticklen) + " 0").attr('stroke', color));
        label = this.text(x - ticklen - 2, ypos, Sai.util.prettystr(val));
        label.attr('x', label.attr('x') - (label.getBBox().width / 2.0));
        labels.push(label);
      }
      ypos -= dy;
    }
    return this.set().push(line, ticks, labels);
  };
  Raphael.fn.sai.prim.popup = function(x, y, texts, opts) {
    var TEXT_LINE_HEIGHT, _b, bg_width, head_text, max_width, py, rect, set, t, text, text_set;
    TEXT_LINE_HEIGHT = 10;
    set = this.set();
    text_set = this.set();
    max_width = 0;
    py = y + 5 + (TEXT_LINE_HEIGHT / 2);
    if ('__HEAD__' in texts) {
      head_text = this.text(x, py, texts['__HEAD__']).attr({
        'fill': '#cfc',
        'font-size': '12',
        'font-weight': 'bold'
      });
      max_width = Math.max(max_width, head_text.getBBox().width);
      text_set.push(head_text);
      py += (TEXT_LINE_HEIGHT + 2) + 5;
    }
    _b = texts;
    for (text in _b) { if (__hasProp.call(_b, text)) {
      if (text === '__HEAD__') {
        continue;
      }
      t = this.text(x + 5, py, text + ": " + texts[text]).attr({
        'fill': 'white',
        'font-weight': 'bold'
      });
      t.translate(t.getBBox().width / 2, 0);
      max_width = Math.max(max_width, t.getBBox().width);
      py += TEXT_LINE_HEIGHT;
      text_set.push(t);
    }}
    bg_width = max_width + 10;
    rect = this.rect(x, y, bg_width, (py - y), 5).attr({
      'fill': 'black',
      'fill-opacity': '.85',
      'stroke': 'black'
    });
    typeof head_text === "undefined" || head_text == undefined ? undefined : head_text.translate(bg_width / 2);
    return text_set.toFront();
  };
  Raphael.fn.sai.prim.legend = function(x, y, max_width, colors) {
    var _b, key, line_height, px, py, r, set, spacing, t, text;
    spacing = 15;
    line_height = 14;
    y -= line_height;
    set = this.set();
    px = x;
    py = y;
    _b = colors;
    for (text in _b) { if (__hasProp.call(_b, text)) {
      t = this.text(px + 14, py, text);
      t.translate(t.getBBox().width / 2, t.getBBox().height / 2);
      r = this.rect(px, py, 9, 9).attr({
        'fill': colors[text]
      });
      key = this.set().push(t, r);
      if ((px - x) + spacing + key.getBBox().width > max_width) {
        set.translate(0, -line_height);
        key.translate(x - px, y - py);
        px = x;
        py = y;
      }
      px += key.getBBox().width + spacing;
      set.push(key);
    }}
    return set;
  };
  Raphael.fn.sai.prim.info = function(x, y, max_width, info) {
    var _b, label, line_height, px, py, set, spacing, t;
    spacing = 15;
    line_height = 14;
    set = this.set();
    px = x;
    py = y;
    _b = info;
    for (label in _b) { if (__hasProp.call(_b, label)) {
      if (info[label] === null) {
        continue;
      }
      t = this.text(px, py, label + ': ' + Sai.util.prettystr(info[label]));
      t.translate(t.getBBox().width / 2, t.getBBox().height / 2);
      if ((px - x) + spacing + t.getBBox().width > max_width) {
        t.translate(x - px, line_height);
        px = x;
        py += line_height;
      }
      px += t.getBBox().width + spacing;
      set.push(t);
    }}
    return set;
  };
})();
